package dde.gymnasiumnippes.vertretungsplan;

import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.apache.http.client.ClientProtocolException;
import org.w3c.dom.Text;

import java.io.IOException;
import java.util.Arrays;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static dde.gymnasiumnippes.vertretungsplan.MainActivity.currentname;
import static dde.gymnasiumnippes.vertretungsplan.MainActivity.namen;

public class StundenplanActivity extends AppCompatActivity {
    ScrollView scrollView;
    WebView webView;
    TextView text;
    SharedPreferences pref;
    Schueler meinSchueler;
    Datum Datum;
    int Index = Arrays.asList(namen).indexOf(currentname);
    String kalenderwochejetzt;
    MenuItem pfeil;
    MenuItem pfeil2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.stundenplan_activity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(currentname);

        text = findViewById(R.id.textView1);
        Datum = new Datum();
        kalenderwochejetzt = Integer.toString(Datum.getKalenderwoche());
        meinSchueler = new Schueler();
        Uri.Builder builder = new Uri.Builder();
        builder.scheme("https")
                .authority("web.gymnasium-nippes.de")
                .appendPath("~autolog")
                .appendPath("schueler")
                .appendPath(kalenderwochejetzt)
                .appendPath("s")
                .appendPath(meinSchueler.Schuelerid[Index]);
        String url = (String) builder.toString() + ".htm";

        pref = getSharedPreferences("app", Context.MODE_PRIVATE);
        WebView webView = findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(wvc);
        webView.loadUrl(url);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu1, menu);
        pfeil = menu.findItem(R.id.letzteWoche);
        pfeil2 = menu.findItem(R.id.naechsteWoche);
        pfeil.setVisible(false);
        return true;
    }

    public WebViewClient wvc = new WebViewClient() {

        @SuppressWarnings("deprecation")
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            try {
                final String acToken = "aG9sbGFuZDpmYXJmcm9taGhvbWU=";

                OkHttpClient okHttpClient = new OkHttpClient();
                Request request = new Request.Builder().url(url).addHeader("Authorization", "Basic " + acToken)
                        .build();

                Response response = okHttpClient.newCall(request).execute();

                return new WebResourceResponse(response.header("content-type", response.body().contentType().type()),
                        response.header("content-encoding", "utf-8"),
                        response.body().byteStream());


            } catch (ClientProtocolException e) {
                return null;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    };


    //TODO junge du kleiner Lappen lern jetzt mal wie jsoup geht damit du die html datei kriegen kannst
   /* private void getWebsite() {
       Document doc = null;
        try {
            doc = Jsoup.connect("https://web.gymnasium-nippes.de/~autolog/schueler/ ").get();


            String title = doc.title();
        } catch (IOException e) {

        }


    } */

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.naechsteWoche:
                Datum = new Datum();
                kalenderwochejetzt = Integer.toString(Datum.getKalenderwoche()+1);
                meinSchueler = new Schueler();
                Uri.Builder builder = new Uri.Builder();
                builder.scheme("https")
                        .authority("web.gymnasium-nippes.de")
                        .appendPath("~autolog")
                        .appendPath("schueler")
                        .appendPath(kalenderwochejetzt)
                        .appendPath("s")
                        .appendPath(meinSchueler.Schuelerid[Index]);
                String url = (String) builder.toString() + ".htm";
                WebView webView = findViewById(R.id.webview);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.setWebViewClient(wvc);
                webView.loadUrl(url);
                Toast.makeText(this, "NÄCHSTE WOCHE WIRD ANGEZEIGT", Toast.LENGTH_SHORT).show();
                pfeil.setVisible(true);
                pfeil2.setVisible(false);

                return true;
            case R.id.letzteWoche:
                kalenderwochejetzt = Integer.toString(Datum.getKalenderwoche());
                builder = new Uri.Builder();
                builder.scheme("https")
                        .authority("web.gymnasium-nippes.de")
                        .appendPath("~autolog")
                        .appendPath("schueler")
                        .appendPath(kalenderwochejetzt)
                        .appendPath("s")
                        .appendPath(meinSchueler.Schuelerid[Index]);
                url = (String) builder.toString() + ".htm";
                Toast.makeText(this, "JETZIGE WOCHE WIRD ANGEZEIGT" , Toast.LENGTH_SHORT).show();
                webView = findViewById(R.id.webview);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.setWebViewClient(wvc);
                webView.loadUrl(url);
                pfeil2.setVisible(true);
                pfeil.setVisible(false);



                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
