package dde.gymnasiumnippes.vertretungsplan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private Button redirect;
    public static String[] namen = new String[]{
            "Abels Franziska 20030322", "Abram Jeremias 20020721", "Akin Louis 20031208", "Aksu Gülperi 20040430", "Al-Aydani Mohamed Akeel Ghaleb 20040401", "Alibas Noel", "Altiner Zeynep", "Altunsuyu Atilla 20060411", "Altunsuyu Feray-Elif 20040220", "Alzierj Mohamed 20020517", "Amiri Mojib 20041014", "Amsink Henry 20021002", "Arici Murat 20020813", "Atmaca Tasin 20020808", "Ay Zeynep 20030125", "Azemi Alberina 20030608", "Azevedo Neuschütz Bruno 20050403", "Bacher Vilem", "Bahlmann Marie 20030525", "Bakircioglu Dilara 20030926", "Bakis Ekin 20050211", "Balduin Luisa Silvia 20021203", "Barbarotto Rinaldo 20030131", "Bartels Elias 20031120", "Beckers Salvatore 20050330", "Beemelmanns Anton 20030120", "Beemelmanns Flora Luise 20040917", "Beier Lars 20041012", "Bekiroglu Baha 20030106", "Benstem Zoe Bella 20041230", "Bernsmann Hannes 20020920", "Bernsmann Tabea 20050926", "Billor Leyan 20021114", "Blankenmeier Helena Theresa 20030629", "Bleikertz Catalina", "Blindert Ruben 20051023", "Bode Kai 20030724", "Bonnen Annika 20030804", "Brock Konrad 20050814", "Buchanan Riva Jack 20011104", "Bucioglu Abdo John 20030830", "Budde Ellen Lilly 20050203", "Bünhove Cecilie Helena 20050406", "Burauer Christian 20040612", "Busch Celina 20030225", "Capkin Aysu 20030624", "Cedzich Alexander Josef 20041228", "Celik Berkan 20021016", "Celilkkale Ilayda", "Chimienti Luis Leonardo 20040113", "Cimino Nunziata 20030425", "Colmer Ben 20031008", "Creydt Julia Sophie 20031116", "Das Zoe 20041029", "Demiröz Habibe Zehra", "Diehl Johannes 20040407", "Dinc Esat Kaan 20040831", "Direk  Süeda Begum 20031117", "Doepner Nick 20040213", "Dong Zhixing Diny 20011210", "Drosihn Marie Lara 20030408", "Dunkel Jonas 20040120", "Dyckx Charlotte Pauline", "Effer Jasmin 20040720", "Effer Laura Agnes 20050217", "Egerland Hannah Leonie 20050529", "Egert Florian", "Eis Elisabeth 20050518", "Ejiofor Kelly 20040418", "Elallali Mohamed 20030201", "Elder Helene Meret Raphaela 20050419", "Enger Lisa Merit 20041003", "Enns Finn Elea 20041006", "Erler Mara-Luisa 20030807", "Erol Ilayda 20040709", "Evci Melisa Meryem 20030531", "Everding Jakob Elias 20030710", "Ewel Juri 20040628", "Faber Julius  Paul 20040121", "Fielen Fabienne 20030519", "Fodera Ben 20030226", "Franke Lynn 20050328", "Friedebold Arne 20041227", "Friedrichsen Finnja", "Fuchs Lilith 20031224", "Geiger Anna Julie 20030526", "Geisler Finn 20030926", "Gernert Luis 20050420", "Götz Margarita 20030717", "Grott Vivien 20021230", "Grüter Nele 20030604", "Gueye Juliette Catherine 20040119", "Gutkäß Till 20040607", "Hagemeister Gina Violetta 20031218", "Hanasoglu Tasnim 20021007", "Hauswaldt Maja 20031125", "Hecker Tobias 20040614", "Heimpel Leroi Kaspar 20050928", "Hein Jonne 20040504", "Heinicke Robert 20041219", "Hell Marlon", "Hesse Luca Leander 20030411", "Hisso Malin Emilia 20031107", "Hitit Eda 20050921", "Hohr Franziska 20040615", "Holesch Julian Simon 20050801", "Holesch Sarah Madeleine 20030311", "Hölter Manou Tom 20030321", "Holzapfel Yorick Carl 20040527", "Holzhäuser Muhammad Ali 20040626", "Honold Hanna-Maria 20040907", "Hörner Marlene 20041002", "Huber Sven 20050308", "Hummelt Pauline 20050217", "Illes Keiko Olivia 20030115", "Jaanine Jinane 20020613", "Jakobi Malte", "Jakobs Simon Jonathan 20040501", "Jansen Juleen Mia 20020921", "Janßen Paula", "Jefferson Daniel James 20040610", "Jehle Luca Marie 20031218", "Jenster Ronja Diana 20040227", "Jörns Louis 20030401", "Jürgensen Mats Ole 20040919", "Kabalimu Béla 20050831", "Kachaewa Ismail", "Kaiser Franja 20040702", "Kalde Paula", "Kamlage Jannika Marie 20050531", "Kappe Laurin 20050108", "Kaps Johanna", "Karabegovic Jasmina 20021119", "Katyal Dharna 19990213", "Kaufmann Marlene 20040321", "Kaya Enes Emre", "Kaya Fatih 20031207", "Kayaöz Furkan 20030721", "Keimer Timon", "Kellendonk Lara 20031005", "Kern Julius 20040803", "Ketenci Nil Su 20030313", "Kilinc Melda Elif 20040626", "Kinay Buket 20020930", "Kirmanidis Adam 20030505", "Klabunde Lina 20041205", "Klapheck Lukas 20030403", "Klapheck Moritz 20050426", "Klausener Sebastian 20040902", "Klein Sophie Leni 20030612", "Kleinbongard Marek 20050318", "Kleine Henriette 20050920", "Klütsch Niklas 20050813", "Knipp Jette 20050314", "Kohllöffel Thea Juli 20030728", "König Merve Josefine", "Kons Sophia 20030507", "Körschgen Jona Yunus 20030315", "Korsido Annahita 20001230", "Kösker Zeynep 20031224", "Kraft Judith 20040316", "Kraft Lotta Elisabeth", "Kremenovic Lara", "Krofta Dylan", "Kruse Marie 20050612", "Kürten Pascal 20041204", "Kürten Ruby", "Kurtulus Kerem 20021009", "Küsgen Peter 20050618", "Kuti Milan 20040701", "Kutsch Tillmann 20050127", "Lachenicht Luke 20040106", "Lamers Lenart 20040818", "Lapke Juri 20021024", "Latoszek Giacomo Honore 20030430", "Layer Tim 20040915", "Lectibi Hajar Safia 20050315", "Lill Felix", "Lingscheid-Küppers Sarah 20021222", "Lingscheid Max 20040408", "López Puzberg Nico 20030519", "Ly Madlena Yan 20041104", "Maalal Amir 20041011", "Malangré Laura 20030528", "Mann Laura Anna 20011025", "Marsch Zoe Tabea 20040818", "Matull Leo Daniel Otto 20021211", "Matull Lotte Amelia Luise 20050411", "Meetz Lars 20030515", "Mehmet Alpay 20041116", "Meisenberg Johann 20050329", "Mert Beyza-Nur 20030225", "Mesch Lauritz 20050608", "Metz Paula Marie 20040829", "Meyer Lino Kanoa 20021217", "Mickler Johannes 20051009", "Minor Karla Leonie 20050305", "Mittmann Jakob 20050105", "Mogias Ronja 20030218", "Moser Bravo Leo 20050722", "Moshfeghi Melissa 20010918", "Müller Kevin Alexander 20040524", "Mundt Neele Mari 20050605", "Mundt Nora Maria 20050605", "Nath Akash 20021011", "Ndiaye Coura Johanna 20020926", "Neelsen Arno 20030714", "Negi Vipul 20020225", "Neidhard Marc", "Neumann Marla 20030321", "Nicodemo Nino 20020922", "Nielsen Stella Levinia 20030130", "Nikleniewicz Marvin", "Nörling Anna Maria Helene 20050315", "Nowatschin Raphael 20040605", "Nuradini Bleon 20030421", "Nuradini Sara 20060123", "Obeidi Ismail 20050330", "Oelze Albert Johann 20050526", "Ouardi Ilham-Safaa 20050622", "Özel Emre 20041119", "Özkan Davut Kerem 20030128", "Öztürk Can 20050418", "Öztürk Kaya 20021113", "Panci Lilly 20041114", "Panek Elena 20050530", "Patt Daniel 20031106", "Petronio Rebecca 20031119", "Pham Quynh Nhu 20030709", "Pillich Emma 20051024", "Podolski Maxim 20030331", "Pointner Anastasia 20021229", "Pokrass Denis 20040823", "Polz Konrad 20030117", "Poulakos Luzia 20040227", "Quos Sora 20040930", "Ramirez Donnerstag Amber 20020902", "Reimann Vincent Roque 20050301", "Reimers Emma Sofie 20050427", "Ritzenhoff Antonia 20050528", "Rogge David Miguel", "Rothenbücher Benjamin", "Rother Sophie 20050423", "Sabou Rouh Diba 20011012", "Saher Paulin 20040229", "Sahin Eren 20041022", "Salz Charlotte Saskia Leonie 20031225", "San Berna 20050511", "Sawatzki Alek Jan 20030322", "Schaal Luis Alexander 20021205", "Schall Juri 20030619", "Schaper Mascha 20030712", "Schaper Mika 20051113", "Schellenberger Felix 20030731", "Scherwud Ksenia 20030506", "Schiller Jorma David 20021023", "Schmidt-Jensen Sebastian 20030522", "Schnabel Emily 20040105", "Schnieders Tim 20040205", "Scholz Willie 20050906", "Schreiber Charlotte 20050821", "Schudnagies Oskar Robert 20041225", "Schunck Josephine 20030716", "Schuppert Jonas 20030315", "Schwan Emma 20041209", "Schwark Lisa 20050529", "Schwartz Charlotte Marie 20040201", "Schwerdt Tim 20040430", "Sebastian Emily Fee 20040211", "Sen Nurgül Aleyna 20020204", "Sezek Melek 00000000", "Simanko Timur 20030728", "Singh Tanisha 20030427", "Sochor Ayse 20020728", "Söker Maria 20030318", "Sprenger Bernhard 20020314", "Sprenger Dominik 20040704", "Sprenz Lewin Munir 20041022", "Starbatty Nil 20030904", "Staufenbeyl Marisol 20040110", "Stobbe Thorben 20021015", "Stock Anna Lu 20040812", "Syring Lilly Maewa 20021113", "Szynkowicz Seimon Julian 20041008", "Taner Ardan 20050330", "Tedde Alessio 20020827", "Tekgül Fernur 20021117", "Tekin Esra 20030103", "Thilo Sina 20030307", "Tokbas Saziye-Sila 20040525", "Trigona Esmeralda Maria 20030813", "Tritz Yannick", "Türkmen Kaan", "Uyanik Selin 20040710", "van den Hövel Ben 20040213", "Vila Alvarez Guillermo 20031205", "Vischer Maxima 20031117", "Vogel Noah Gabriel 20040305", "von der Wettern Jonathan 20021201", "von Reth Leandra 20030417", "Wagner Franca 20030221", "Wall Morris Oskar 20021023", "Weilandt Kasimir 20031107", "Weinhold Lena 20020829", "Weßler Paul 20050301", "Wilkens Maximilian 20021210", "Wingerath Merle", "Wittkamp Felix 20041025", "Woelk Jana 20040801", "Wohlenberg Karolin Ann-Luise 20040112", "Wohlfromm Luzia 20041212", "Wojcik Karoline 20020927", "Yilmaz Alihan 20040208", "Zerres Jana Maria 20031123", "Zerweck Aaron Gerhard", "Zug Henriette Marie"
    }; // Namen aller Schueler
    public static String currentname;
    private long backPressedTime;
    private Toast backToast;
    private AutoCompleteTextView NamenText;
    private boolean itemangeklickt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NamenText = findViewById(R.id.autoCompleteTextView);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, namen);
        NamenText.setAdapter(adapter);
        redirect = (Button) findViewById(R.id.redirect);
        itemangeklickt =false;
      //*  NamenText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        //*   @Override
        //*   public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //*      if (itemangeklickt==false){
        //*         itemangeklickt = true;
        //*     }
        //*       if (itemangeklickt==true){
        //*         String selectedItem=NamenText.getAdapter().getItem(position).toString();
        //*
        //*
        //*      }
        //*   } //
        //*  });
    }


    public void activitywechsel(View view) {
        currentname = NamenText.getText().toString();
        Intent i = new Intent(MainActivity.this, StundenplanActivity.class);

            startActivity(i);

    }


    @Override
    public void onBackPressed() {


        if (backPressedTime + 3000 > System.currentTimeMillis()) {
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(getBaseContext(), "Drücken Sie zum Beenden erneut zurück", Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }

}